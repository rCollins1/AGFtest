var firstName = prompt("What is your first name?");
var lastName = prompt("What is your last name?");
var age = prompt("What is your age?");

console.log("Your name is " + firstName + " " + lastName + ".")
console.log("You are " + age + " years old.")