var correctNumber = 7;

var guess = Number(prompt("Guess a number:"));

if (guess === correctNumber)
	alert("YOU'RE RIGHT WOOOOOO!");

else if (guess > correctNumber)
	alert("TOO HIGH");

else
	alert("TOO LOW");