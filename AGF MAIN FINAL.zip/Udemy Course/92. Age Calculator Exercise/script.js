var years = prompt("How old are you?");

var days = 365.25 * years

alert("You have been alive approx. " + days + " days.")