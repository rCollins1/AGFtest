// VERSION 2 (without bonus)

/*var answer = prompt("Are we there yet?");

while ((answer !== "yeah") && (answer !== "yes"))
	var answer = prompt("Are we there yet?");

alert("YAY!");*/



// VERSION 2 (with bonus)

var answer = prompt("Are we there yet?");

while (answer.indexOf("yes") === -1)
	var answer = prompt("Are we there yet?");

alert("YAY!");