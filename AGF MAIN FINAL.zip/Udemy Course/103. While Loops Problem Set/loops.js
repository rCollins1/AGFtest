var one, two, three, four;
one = -10;
two = 10;
three = 300;
four = 5;

while (one < 20){
	console.log(one);
	one++;
}

while (two < 41){
	if (two % 2 === 0)
		console.log(two);
	two++;
}

while (three < 334){
	if (three % 2 !== 0)
		console.log(three);
	three++;
}

while (four < 51){
	if ((four % 5 === 0) && (four % 3 === 0))
	console.log(four);
	four++;
}
